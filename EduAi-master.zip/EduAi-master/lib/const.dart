const String GEMINI_API_KEY = "AIzaSyCrTO0QU4lO1qjbmsmfCMz-LApyWV49KAo";
